console.log("Hello World");
document.getElementById('studentForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const rollno = document.getElementById('rollno').value;
    const classValue = document.getElementById('class').value;
    const gender = document.querySelector('input[name="gender"]:checked').value;

    document.getElementById('cardName').textContent = name;
    document.getElementById('cardRollno').textContent = rollno;
    document.getElementById('cardClass').textContent = "Class " + classValue;
    document.getElementById('cardGender').textContent = gender;
    const student = {
        name: name,
        rollno: rollno,
        class: classValue,
        gender: gender
    };
    window.localStorage.setItem('student', JSON.stringify(student));

    document.getElementById('studentTable').style.display = 'block';
    document.getElementById('studentForm').reset();
    document.getElementById('studentTable').scrollIntoView({ behavior: 'smooth' });
});

window.onload = function () {
    const object = window.localStorage.getItem('student');
    console.log(JSON.parse(object));
}

//const studentData = document.getElementById('studentTable');


//const getsomeData = () => {
//  console.log("Hello World");

//fetch('https://jsonplaceholder.typicode.com/posts').then(response => response.json())
//.then(data => studentData.innerHTML = data.map(student => `<tr><td>${student.title}</td><td>${student.body}</td></tr>`).join(''))
//const response = fetch('https://jsonplaceholder.typicode.com/posts');
//console.log(response);

//}

//getsomeData();


const studentfrom = document.getElementById('studentTable');
const getStudentDataThen = () => {


    fetch('https://jsonplaceholder.typicode.com/posts')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            //console.log("Data received:", data);
            studentfrom.innerHTML = data.map(student => `<tr><td>${student.title}</td><td>${student.body}</td></tr>`).join('');
        })
        .catch(error => {
            //console.error('Error fetching data:', error);
            studentfrom.innerHTML = `<tr><td colspan="3">Error loading data: ${error.message}</td></tr>`;
        });
}


